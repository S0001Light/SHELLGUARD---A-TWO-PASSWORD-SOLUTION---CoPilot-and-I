# crypto_utils.py
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import json

def pad(data):
    pad_len = 16 - (len(data) % 16)
    return data + chr(pad_len) * pad_len

def unpad(data):
    pad_len = data[-1]
    return data[:-pad_len]

def encrypt_json(data, keyfile, outfile):
    key = get_random_bytes(32)
    with open(keyfile, "wb") as f:
        f.write(key)

    cipher = AES.new(key, AES.MODE_CBC)
    iv = cipher.iv
    encrypted = cipher.encrypt(pad(json.dumps(data)).encode())

    with open(outfile, "wb") as f:
        f.write(iv + encrypted)

def decrypt_json(keyfile, infile):
    with open(keyfile, "rb") as f:
        key = f.read()

    with open(infile, "rb") as f:
        blob = f.read()

    iv = blob[:16]
    encrypted = blob[16:]

    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted = cipher.decrypt(encrypted)
    return json.loads(unpad(decrypted).decode())
