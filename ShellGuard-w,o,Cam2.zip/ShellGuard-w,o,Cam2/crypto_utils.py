import json
import os
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes


def load_key(keyfile: str) -> bytes:
    """
    Loads a 32-byte AES key from keyfile.
    If keyfile does not exist, it is created.
    """
    if not os.path.exists(keyfile):
        key = get_random_bytes(32)  # AES-256
        with open(keyfile, "wb") as f:
            f.write(key)
    else:
        with open(keyfile, "rb") as f:
            key = f.read()

    return key


def encrypt_json(keyfile: str, data: dict, outfile: str) -> None:
    """
    Encrypts a JSON dict using AES-GCM and writes it to outfile.
    """
    key = load_key(keyfile)
    cipher = AES.new(key, AES.MODE_GCM)

    plaintext = json.dumps(data).encode("utf-8")
    ciphertext, tag = cipher.encrypt_and_digest(plaintext)

    blob = {
        "nonce": cipher.nonce.hex(),
        "tag": tag.hex(),
        "ciphertext": ciphertext.hex()
    }

    with open(outfile, "w") as f:
        json.dump(blob, f)


def decrypt_json(keyfile: str, infile: str) -> dict:
    """
    Decrypts AES-GCM encrypted JSON file and returns the dict.
    """
    key = load_key(keyfile)

    with open(infile, "r") as f:
        blob = json.load(f)

    nonce = bytes.fromhex(blob["nonce"])
    tag = bytes.fromhex(blob["tag"])
    ciphertext = bytes.fromhex(blob["ciphertext"])

    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    plaintext = cipher.decrypt_and_verify(ciphertext, tag)

    return json.loads(plaintext.decode("utf-8"))
