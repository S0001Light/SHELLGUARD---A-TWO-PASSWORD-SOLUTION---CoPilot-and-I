import tkinter as tk
from tkinter import messagebox
import hashlib
from crypto_utils import encrypt_json

def save_password():
    text_pwd = entry_text.get()
    grid1 = entry_grid1.get().upper().split(",")
    grid2 = entry_grid2.get().upper().split(",")

    if not text_pwd:
        messagebox.showerror("Error", "Text password cannot be empty.")
        return

    if len(grid1) == 0 or len(grid2) == 0:
        messagebox.showerror("Error", "Grid passwords cannot be empty.")
        return

    data = {
        "TEXT_HASH": hashlib.sha256(text_pwd.encode()).hexdigest(),
        "GRID1": grid1,
        "GRID2": grid2
    }

    encrypt_json("key.bin", data, "password.dat")

    messagebox.showinfo("Success", "Encrypted password.dat created!")

app = tk.Tk()
app.title("Password File Creator")
app.geometry("500x300")
app.configure(bg="#000000")

label1 = tk.Label(app, text="Text Password:", fg="#00ff00", bg="#000000", font=("Courier New", 14))
label1.pack(pady=5)
entry_text = tk.Entry(app, width=40, font=("Courier New", 14), fg="#00ff00", bg="#001100", insertbackground="#00ff00")
entry_text.pack()

label2 = tk.Label(app, text="Alphabet Grid (A,B,C,...):", fg="#00ff00", bg="#000000", font=("Courier New", 14))
label2.pack(pady=5)
entry_grid1 = tk.Entry(app, width=40, font=("Courier New", 14), fg="#00ff00", bg="#001100", insertbackground="#00ff00")
entry_grid1.pack()

label3 = tk.Label(app, text="Number Grid (0,1,2,*...):", fg="#00ff00", bg="#000000", font=("Courier New", 14))
label3.pack(pady=5)
entry_grid2 = tk.Entry(app, width=40, font=("Courier New", 14), fg="#00ff00", bg="#001100", insertbackground="#00ff00")
entry_grid2.pack()

btn = tk.Button(app, text="Create password.dat", command=save_password, fg="#00ff00", bg="#003300", font=("Courier New", 16))
btn.pack(pady=20)

app.mainloop()
