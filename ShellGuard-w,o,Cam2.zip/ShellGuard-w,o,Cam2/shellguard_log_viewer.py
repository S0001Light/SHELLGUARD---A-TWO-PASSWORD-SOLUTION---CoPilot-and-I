import os
import time
import csv
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from crypto_utils import decrypt_json

CAPTURE_FOLDER = r"C:\ShellGuard\captures"
CRITICAL_LOG_FOLDER = r"C:\ShellGuard\captures\critical"


class ShellGuardLogViewer(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("ShellGuard Log Viewer")
        self.geometry("1100x650")
        self.configure(bg="#000000")

        self.log_type = tk.StringVar(value="normal")
        self.filter_success = tk.StringVar(value="all")
        self.filter_event = tk.StringVar(value="all")
        self.filter_start = tk.StringVar()
        self.filter_end = tk.StringVar()

        self.build_ui()
        self.load_logs()

    def build_ui(self):
        # Header
        header = tk.Frame(self, bg="#000000")
        header.pack(fill="x", pady=10)

        tk.Label(
            header,
            text="ShellGuard Log Viewer",
            fg="#00ff00",
            bg="#000000",
            font=("Courier New", 22, "bold")
        ).pack(side="left", padx=10)

        # Log type selector
        selector = tk.Frame(header, bg="#000000")
        selector.pack(side="right", padx=10)

        tk.Radiobutton(selector, text="Normal Logs", variable=self.log_type, value="normal",
                       command=self.load_logs, fg="#00ff00", bg="#000000",
                       selectcolor="#000000", font=("Courier New", 12)).pack(side="left", padx=5)

        tk.Radiobutton(selector, text="Critical Logs", variable=self.log_type, value="critical",
                       command=self.load_logs, fg="#ff0000", bg="#000000",
                       selectcolor="#000000", font=("Courier New", 12)).pack(side="left", padx=5)

        # Filters
        filter_frame = tk.Frame(self, bg="#000000")
        filter_frame.pack(fill="x", pady=5)

        tk.Label(filter_frame, text="Success:", fg="#00ff00", bg="#000000",
                 font=("Courier New", 12)).pack(side="left", padx=5)
        ttk.Combobox(filter_frame, textvariable=self.filter_success,
                     values=["all", "true", "false"], width=8).pack(side="left")

        tk.Label(filter_frame, text="Event:", fg="#00ff00", bg="#000000",
                 font=("Courier New", 12)).pack(side="left", padx=10)
        ttk.Combobox(filter_frame, textvariable=self.filter_event,
                     values=["all", "ATTEMPT", "CRITICAL", "LOCKOUT"], width=10).pack(side="left")

        tk.Label(filter_frame, text="Start Date (YYYY-MM-DD):", fg="#00ff00",
                 bg="#000000", font=("Courier New", 12)).pack(side="left", padx=10)
        tk.Entry(filter_frame, textvariable=self.filter_start, width=12,
                 bg="#001100", fg="#00ff00").pack(side="left")

        tk.Label(filter_frame, text="End Date:", fg="#00ff00",
                 bg="#000000", font=("Courier New", 12)).pack(side="left", padx=10)
        tk.Entry(filter_frame, textvariable=self.filter_end, width=12,
                 bg="#001100", fg="#00ff00").pack(side="left")

        tk.Button(filter_frame, text="Apply Filters", command=self.load_logs,
                  bg="#004400", fg="#00ff00", font=("Courier New", 12)).pack(side="left", padx=10)

        # Treeview
        tree_frame = tk.Frame(self, bg="#000000")
        tree_frame.pack(fill="both", expand=True, padx=10, pady=10)

        columns = ("timestamp", "event", "success", "entered_hash",
                   "grid1", "grid2", "failed_attempts")

        self.tree = ttk.Treeview(tree_frame, columns=columns, show="headings")

        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview", background="#000000", foreground="#00ff00",
                        fieldbackground="#000000", rowheight=24,
                        font=("Courier New", 10))
        style.configure("Treeview.Heading", background="#003300",
                        foreground="#00ff00", font=("Courier New", 11, "bold"))

        for col in columns:
            self.tree.heading(col, text=col.upper())
            self.tree.column(col, width=150, anchor="w")

        self.tree.pack(fill="both", expand=True)

        # Footer
        footer = tk.Frame(self, bg="#000000")
        footer.pack(fill="x", pady=10)

        tk.Button(footer, text="Export CSV", command=self.export_csv,
                  bg="#004400", fg="#00ff00", font=("Courier New", 14)).pack(side="left", padx=10)

        tk.Button(footer, text="Refresh", command=self.load_logs,
                  bg="#004400", fg="#00ff00", font=("Courier New", 14)).pack(side="left", padx=10)

        tk.Button(footer, text="Exit", command=self.destroy,
                  bg="#440000", fg="#ff0000", font=("Courier New", 14)).pack(side="right", padx=10)

    def passes_filters(self, data):
        # Success filter
        if self.filter_success.get() != "all":
            if str(data.get("success", "")).lower() != self.filter_success.get():
                return False

        # Event filter
        event = data.get("event", "ATTEMPT")
        if self.filter_event.get() != "all" and event != self.filter_event.get():
            return False

        # Date range filter
        timestamp = data.get("timestamp", "")
        if timestamp:
            try:
                ts_struct = time.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
                ts_epoch = time.mktime(ts_struct)

                if self.filter_start.get():
                    start_epoch = time.mktime(time.strptime(self.filter_start.get(), "%Y-%m-%d"))
                    if ts_epoch < start_epoch:
                        return False

                if self.filter_end.get():
                    end_epoch = time.mktime(time.strptime(self.filter_end.get(), "%Y-%m-%d"))
                    if ts_epoch > end_epoch:
                        return False
            except Exception:
                pass

        return True

    def load_logs(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        folder = CAPTURE_FOLDER if self.log_type.get() == "normal" else CRITICAL_LOG_FOLDER
        prefix = "log_" if self.log_type.get() == "normal" else "critical_"

        if not os.path.exists(folder):
            return

        files = sorted([f for f in os.listdir(folder) if f.startswith(prefix)])

        for fname in files:
            full_path = os.path.join(folder, fname)
            try:
                data = decrypt_json("key.bin", full_path)
            except Exception:
                continue

            if not self.passes_filters(data):
                continue

            timestamp = data.get("timestamp", "")
            event = data.get("event", "ATTEMPT")
            success = str(data.get("success", ""))
            entered_hash = data.get("entered_hash", "")
            if entered_hash:
                entered_hash = entered_hash[:16] + "..."

            grid1 = ",".join(data.get("grid_selected_1", []))
            grid2 = ",".join(data.get("grid_selected_2", []))
            failed_attempts = data.get("failed_attempts", "")

            row_id = self.tree.insert("", "end",
                                      values=(timestamp, event, success,
                                              entered_hash, grid1, grid2,
                                              failed_attempts))

            # Color coding
            if event == "CRITICAL" or event == "LOCKOUT":
                self.tree.item(row_id, tags=("critical",))
            elif success == "true":
                self.tree.item(row_id, tags=("success",))
            else:
                self.tree.item(row_id, tags=("fail",))

        self.tree.tag_configure("success", foreground="#00ff00")
        self.tree.tag_configure("fail", foreground="#ffff00")
        self.tree.tag_configure("critical", foreground="#ff0000")

    def export_csv(self):
        save_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV Files", "*.csv")],
            title="Export ShellGuard Logs"
        )

        if not save_path:
            return

        rows = [self.tree.item(row)["values"] for row in self.tree.get_children()]

        with open(save_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["timestamp", "event", "success",
                             "entered_hash", "grid1", "grid2",
                             "failed_attempts"])
            writer.writerows(rows)

        messagebox.showinfo("Export Complete", "Logs exported successfully.")


if __name__ == "__main__":
    ShellGuardLogViewer().mainloop()
