import tkinter as tk
from tkinter import messagebox
import ctypes
import hashlib
import time
import os
from crypto_utils import decrypt_json
from crypto_utils import encrypt_json   # you already have decrypt_json

# Colors
BG_COLOR = "#000000"
FG_COLOR = "#00ff00"
BOX_COLOR = "#003300"
BOX_ACTIVE = "#00aa00"
BOX_HOVER = "#006600"

CRITICAL_LOG_FOLDER = r"C:\ShellGuard\captures\critical"


def lock_workstation():
    ctypes.windll.user32.LockWorkStation()


class Tile(tk.Frame):
    def __init__(self, parent, char, callback):
        super().__init__(parent, bg=BG_COLOR)

        self.char = char.upper()
        self.active = False
        self.callback = callback

        self.lbl = tk.Label(
            self,
            text=self.char,
            font=("Courier New", 14),
            fg=FG_COLOR,
            bg=BG_COLOR
        )
        self.lbl.pack(side="left", padx=4)

        self.box = tk.Label(
            self,
            width=4,
            height=2,
            bg=BOX_COLOR,
            bd=2,
            relief="solid"
        )
        self.box.pack(side="left", padx=4)

        self.box.bind("<Button-1>", self.toggle)
        self.box.bind("<Enter>", self.hover_on)
        self.box.bind("<Leave>", self.hover_off)

    def hover_on(self, event):
        if not self.active:
            self.box.configure(bg=BOX_HOVER)

    def hover_off(self, event):
        if not self.active:
            self.box.configure(bg=BOX_COLOR)

    def toggle(self, event):
        self.active = not self.active
        self.box.configure(bg=BOX_ACTIVE if self.active else BOX_COLOR)
        self.callback(self.char, self.active)

    def reset(self):
        self.active = False
        self.box.configure(bg=BOX_COLOR)


class ShellGuardApp(tk.Tk):
    def __init__(self):
        super().__init__()

        self.failed_attempts = 0
        self.max_failed_attempts = 5

        # Load encrypted password file
        data = decrypt_json("key.bin", "password.dat")
        self.text_hash = data["TEXT_HASH"]
        self.grid_required_1 = [c.upper() for c in data["GRID1"]]
        self.grid_required_2 = [c.upper() for c in data["GRID2"]]

        # Cleanup old logs automatically
        self.cleanup_old_logs()

        self.grid_selected_1 = set()
        self.grid_selected_2 = set()

        self.title("ShellGuard Login")
        self.configure(bg=BG_COLOR)
        self.resizable(False, False)

        # Fullscreen + lock behavior
        self.attributes("-fullscreen", True)
        self.attributes("-topmost", True)

        # Disable close button
        self.protocol("WM_DELETE_WINDOW", lambda: None)

        # Key blocking
        self.bind("<Alt-F4>", lambda e: "break")
        self.bind("<Control-w>", lambda e: "break")
        self.bind("<Alt-space>", lambda e: "break")
        self.bind("<Escape>", lambda e: "break")
        self.bind("<KeyPress>", self.block_windows_key)
        self.bind("<Alt-Tab>", lambda e: "break")
        self.bind("<Control-Tab>", lambda e: "break")
        self.bind("<Shift-Alt-Tab>", lambda e: "break")
        self.bind("<Control-Escape>", lambda e: "break")

        self.build_ui()
        
    def write_audit_log(self, success, entered_hash):
        """
        Writes an encrypted audit log entry into the captures folder.
        """

        log_entry = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "success": success,
            "entered_hash": entered_hash,
            "grid_selected_1": sorted(self.grid_selected_1),
            "grid_selected_2": sorted(self.grid_selected_2),
            "failed_attempts": self.failed_attempts
        }

        # Ensure folder exists
        folder = r"C:\ShellGuard\captures"
        os.makedirs(folder, exist_ok=True)

        filename = os.path.join(folder, f"log_{int(time.time())}.bin")

        # Encrypt using your existing AES system
        encrypt_json("key.bin", log_entry, filename)
        
    def cleanup_old_logs(self):
        """
        Deletes encrypted audit logs older than 90 days.
        """
        folder = r"C:\ShellGuard\captures"
        if not os.path.exists(folder):
            return

        now = time.time()
        ninety_days = 90 * 24 * 60 * 60

        for filename in os.listdir(folder):
            if not filename.startswith("log_") or not filename.endswith(".bin"):
                continue

            full_path = os.path.join(folder, filename)

            try:
                file_time = os.path.getmtime(full_path)
                if now - file_time > ninety_days:
                    os.remove(full_path)
            except Exception:
                pass

    def write_critical_log(self, event_type, entered_hash):
        """
        Writes an encrypted critical event log that is NEVER deleted.
        """

        os.makedirs(CRITICAL_LOG_FOLDER, exist_ok=True)

        log_entry = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "event": event_type,
            "entered_hash": entered_hash,
            "grid_selected_1": sorted(self.grid_selected_1),
            "grid_selected_2": sorted(self.grid_selected_2),
            "failed_attempts": self.failed_attempts
        }

        filename = os.path.join(
            CRITICAL_LOG_FOLDER,
            f"critical_{int(time.time())}.bin"
        )

        encrypt_json("key.bin", log_entry, filename)

    def block_windows_key(self, event):
        if event.keysym in ["Super_L", "Super_R"]:
            return "break"

    def build_ui(self):
        container = tk.Frame(self, bg=BG_COLOR)
        container.place(relx=0.5, rely=0.5, anchor="center")

        self.tiles_1 = self.build_grid(
            container,
            "Alphabet Grid (A–Z)",
            list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        )

        self.tiles_2 = self.build_grid(
            container,
            "Number & Symbol Grid (0–9 * ! #)",
            list("0123456789*!#")
        )

        self.entry = tk.Entry(
            container,
            width=25,
            font=("Courier New", 18),
            fg=FG_COLOR,
            bg="#001100",
            insertbackground=FG_COLOR,
            show="•"
        )
        self.entry.pack(pady=20)
        
        keyboard = TouchKeyboard(container, self.entry)
        keyboard.pack(pady=20)


        self.show_var = tk.IntVar()
        show_btn = tk.Checkbutton(
            container,
            text="Show Password",
            variable=self.show_var,
            command=self.toggle_show,
            bg=BG_COLOR,
            fg=FG_COLOR,
            font=("Courier New", 14),
            selectcolor=BG_COLOR
        )
        show_btn.pack()

        tk.Button(
            container,
            text="Reset Alphabet Grid",
            command=self.reset_grid_1,
            font=("Courier New", 14),
            bg="#004400",
            fg=FG_COLOR
        ).pack(pady=10)

        tk.Button(
            container,
            text="Reset Number Grid",
            command=self.reset_grid_2,
            font=("Courier New", 14),
            bg="#004400",
            fg=FG_COLOR
        ).pack(pady=10)

        tk.Button(
            container,
            text="ENTER",
            command=self.on_enter,
            font=("Courier New", 18),
            bg="#00aa00",
            fg=FG_COLOR
        ).pack(pady=20)

    def build_grid(self, parent, label_text, char_list):
        tk.Label(
            parent,
            text=label_text,
            fg=FG_COLOR,
            bg=BG_COLOR,
            font=("Courier New", 18)
        ).pack(pady=10)

        frame = tk.Frame(parent, bg=BG_COLOR)
        frame.pack()

        tiles = []
        row_frame = tk.Frame(frame, bg=BG_COLOR)
        row_frame.pack()

        for i, ch in enumerate(char_list):
            if i % 13 == 0:
                row_frame = tk.Frame(frame, bg=BG_COLOR)
                row_frame.pack()

            tile = Tile(row_frame, ch, self.toggle_tile)
            tile.pack(side="left", padx=6, pady=6)
            tiles.append(tile)

        return tiles

    def toggle_tile(self, char, active):
        if char in [t.char for t in self.tiles_1]:
            if active:
                self.grid_selected_1.add(char)
            else:
                self.grid_selected_1.discard(char)
        else:
            if active:
                self.grid_selected_2.add(char)
            else:
                self.grid_selected_2.discard(char)

    def reset_grid_1(self):
        self.grid_selected_1.clear()
        for t in self.tiles_1:
            t.reset()

    def reset_grid_2(self):
        self.grid_selected_2.clear()
        for t in self.tiles_2:
            t.reset()

    def toggle_show(self):
        self.entry.config(show="" if self.show_var.get() else "•")

    def on_enter(self):
        entered = self.entry.get()  # ← THIS MUST EXIST
        entered_hash = hashlib.sha256(entered.encode()).hexdigest()

        # Write encrypted audit log BEFORE checking success
        self.write_audit_log(
            success=(
                entered_hash == self.text_hash
                and sorted(self.grid_selected_1) == sorted(self.grid_required_1)
                and sorted(self.grid_selected_2) == sorted(self.grid_required_2)
            ),
            entered_hash=entered_hash
        )

        # Now perform the actual authentication check
        if (
            entered_hash == self.text_hash
            and sorted(self.grid_selected_1) == sorted(self.grid_required_1)
            and sorted(self.grid_selected_2) == sorted(self.grid_required_2)
        ):
            self.destroy()
        else:
            self.failed_attempts += 1
            messagebox.showwarning("Access denied", "Incorrect authentication.")

            if self.failed_attempts >= self.max_failed_attempts:
                self.write_critical_log(
                    event_type="LOCKOUT",
                    entered_hash=entered_hash
                )
                lock_workstation()

class TouchKeyboard(tk.Frame):
    def __init__(self, parent, entry_widget):
        super().__init__(parent, bg="#000000")

        self.entry = entry_widget
        self.shift = False
        self.caps = False
        self.hold_job = None

        # QWERTY‑style layout
        self.layout = [
            list("QWERTYUIOP"),
            list("ASDFGHJKL"),
            list("ZXCVBNM"),
            list("0123456789"),
            list("*!#?@%&+=-_/\\<>")
        ]

        self.build_keyboard()

    # ---------- UI BUILD ----------
    def build_keyboard(self):
        for row_keys in self.layout:
            row = tk.Frame(self, bg="#000000")
            row.pack(pady=3)

            for key in row_keys:
                btn = tk.Button(
                    row,
                    text=key,
                    width=4,
                    height=2,
                    font=("Courier New", 16),
                    bg="#003300",
                    fg="#00ff00",
                    activebackground="#00aa00",
                    relief="flat",
                )
                btn.pack(side="left", padx=3)

                # Bind press + glow + hold
                btn.bind("<ButtonPress-1>", lambda e, k=key: self.start_press(e, k))
                btn.bind("<ButtonRelease-1>", self.stop_press)

        # Control row
        ctrl = tk.Frame(self, bg="#000000")
        ctrl.pack(pady=10)

        self.add_button(ctrl, "SHIFT", self.toggle_shift, w=8)
        self.add_button(ctrl, "CAPS", self.toggle_caps, w=8)

        # Edit row
        edit = tk.Frame(self, bg="#000000")
        edit.pack(pady=10)

        self.add_button(edit, "SPACE", lambda: self.press(" "), w=12)
        self.add_button(edit, "BACKSPACE", self.backspace, w=12, fg="#ff4444", bg="#440000")

    # ---------- BUTTON CREATOR ----------
    def add_button(self, parent, text, cmd, w=10, fg="#00ff00", bg="#003300"):
        btn = tk.Button(
            parent,
            text=text,
            width=w,
            height=2,
            font=("Courier New", 16),
            bg=bg,
            fg=fg,
            activebackground="#00aa00",
            relief="flat",
            command=cmd
        )
        btn.pack(side="left", padx=10)

    # ---------- PRESS / HOLD / GLOW ----------
    def start_press(self, event, char):
        btn = event.widget
        self.animate_glow(btn)
        self.press(char)
        self.hold_job = btn.after(120, lambda: self.hold_repeat(btn, char))

    def stop_press(self, event):
        if self.hold_job:
            event.widget.after_cancel(self.hold_job)
            self.hold_job = None
        self.reset_glow(event.widget)

    def hold_repeat(self, btn, char):
        self.press(char)
        self.animate_glow(btn)
        self.hold_job = btn.after(80, lambda: self.hold_repeat(btn, char))

    # ---------- GLOW EFFECT ----------
    def animate_glow(self, btn):
        btn.config(bg="#00ff00", fg="#000000")

    def reset_glow(self, btn):
        btn.config(bg="#003300", fg="#00ff00")

    # ---------- KEY LOGIC ----------
    def press(self, char):
        if char.isalpha():
            if self.shift ^ self.caps:
                char = char.upper()
            else:
                char = char.lower()

        self.entry.insert("end", char)

        if self.shift:
            self.shift = False

    def backspace(self):
        current = self.entry.get()
        if current:
            self.entry.delete(len(current)-1, "end")

    def toggle_shift(self):
        self.shift = not self.shift

    def toggle_caps(self):
        self.caps = not self.caps





if __name__ == "__main__":
    ShellGuardApp().mainloop()
